Code by HyperGamesDev | https://hypergamesdev.github.io | https://hyperr.carrd.co
This script requires ffmpeg installed as well as obviously yt-dlp
You can download yt-dlp on GitHub at: https://github.com/yt-dlp/
And FFMPEG at: https://ffmpeg.org/download.html

By putting urls line by line in the inputurls.txt file they will succesively export automatically
And as it is said in the program you can put a timestamp for a snippet
formatted after the url like *01:03^01:37

The downloader does work with *a lot of* different sites, but probably best with YouTube, including the timestamps, they work weird with for ex. TikTok, it glitches out
You can run check_sites.bat to see which sites does it support